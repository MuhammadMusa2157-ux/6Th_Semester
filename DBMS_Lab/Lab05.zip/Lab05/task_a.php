<?php
$test_var = 8.23;

echo (int)$test_var . "<br />";      // Outputs: 8
echo (string)$test_var . "<br />";   // Outputs: 8.23
echo (bool)$test_var . "<br />";     // Outputs: 1 (true)
?>
