<!-- Example 2: A Multiline Comment  -->
<?php 
    /* This is a section 
    of multiline comments 
    which will not be 
    interpreted */

    // single line comment
?>