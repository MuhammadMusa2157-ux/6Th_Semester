<!-- Example 1: Three Different Types of Variable Assignment  -->
<?php 
    $username = "Ali Ahmad"; 
    echo $username; 
    $mycount = 1; 
    echo "<br />".$mycount; 
    $team = array('Maqsood', 'Maryam', 'Adam', 'Naila'); 
    echo "<br />".$team[0]." ".$team[1]." ".$team[2]." ".$team[3]; 
?> 
