<!-- Example 7: Use of ? Operator  -->
<?php 
    $fuel = 9;
    echo $fuel <= 1 ? "Fill tank now" : "There's enough fuel"; 
?> 