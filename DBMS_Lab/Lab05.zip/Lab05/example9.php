Example 9: Using foreach to Loop through Values 
<?php 
    $authors = array("Steinbeck","Kafka","Tolkien","Dickens" ); 
    foreach ( $authors as $val ) { 
        echo $val . "< br/ > "; 
    } 
?>